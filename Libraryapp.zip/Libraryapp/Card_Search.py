from DBConnect import DBCard

database_cards = DBCard()


def view_command():
    for row in database_cards.showLibrarycard():
        print(row)


def search_command(Surname):
    if len(database_cards.search(Surname)) > 0:
        for row in database_cards.search(Surname):
            print(row)
    else:
        print("Такого читателя нет")


search_command(input("Фамилия читателя? "))
