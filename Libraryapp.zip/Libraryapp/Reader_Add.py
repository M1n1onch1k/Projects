from DBConnect import DBReader

database_readers = DBReader()


def add_command(Surname, Name, Patronymic, Adress, Phone):
    database_readers.createReader(Surname, Name, Patronymic, Adress, Phone)


def view_command():
    for row in database_readers.showReaders():
        print(row)


for i in range(5):
    add_command(input("Введите Фамилию: "),
                input("Введите Имя: "),
                input("Введите Отчесвто: "),
                input("Введите Адрес: "),
                input("Введите Телефон: "))

view_command()
