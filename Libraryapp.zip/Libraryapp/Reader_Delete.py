from DBConnect import DBReader

database_readers = DBReader()


def delete_command(id):
    database_readers.deleteReader(id)
    print(f"Данные читателя с id = {id} удалены")


def view_command():
    for row in database_readers.showReaders():
        print(row)


print("Список читателей")
view_command()

id_delete = int(input("Введите id читателя "))
delete_command(id_delete)

print("Список читателей")
view_command()
