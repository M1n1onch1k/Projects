from DBConnect import DBReader

database_readers = DBReader()


def update_command(ID_readers, Surname, Name, Patronymic, Adress, Phone):
    database_readers.updateReader(ID_readers, Surname, Name, Patronymic, Adress, Phone)
    print(f"Данные студента с id = {ID_readers} обновлены")


def view_command():
    for row in database_readers.showReaders():
        print(row)


print("Список читателей")
view_command()

id_update = int(input("Введите id чичателя "))
print("Укажите новые данные: ")
Surname = input("Фамилия")
Name = input("Имя")
Patronymic = input("Отчество")
Adress = input("Адрес")
Phone = input("Телефон")

update_command(id_update, Surname, Name, Patronymic, Adress, Phone)

print("Список читателей")
view_command()
